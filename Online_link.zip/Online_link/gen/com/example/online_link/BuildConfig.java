/** Automatically generated file. DO NOT MODIFY */
package com.example.online_link;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}