package com.example.online_link;

import android.util.Log;

import java.util.HashMap;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	//que[type][no.]
	//pQue[type][now(0) or new(1)]
	//public int[][] que= new int[3][50];
	private int[][] pQue= new int[4][2];
	private int NoOfG = 1;
	//private String url="http://harryapptestingsite.net23.net/index.php";
	private String url;
	private ProgressDialog pDialog;
	private HashMap<String,String> data;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//Bundle ppl = this.getIntent().getExtras();
		//NoOfG = ppl.getInt("NoOfPPL");
		
		SharedPreferences history = getSharedPreferences("NoHistory", 0);
		url = history.getString("URL", "url not set");
		NoOfG = history.getInt("NoOfPPL", 0);
		
		
		pDialog=new ProgressDialog(MainActivity.this);
		pDialog.setIndeterminate(false);
        pDialog.setMessage(""+NoOfG);
        pDialog.show();
        
		//initial all queue position to 0
		for(int i=0; i<4; i++){
			pQue[i][0]=-1;
			pQue[i][1]=-1;
		}
		
		if(history.getInt("noA", -1)!=-1){
			pQue[0][0]=history.getInt("noA", -1);
			pQue[0][1]=history.getInt("neA", -1);
			SendingData("A");
		}
		if(history.getInt("noB", -1)!=-1){
			pQue[1][0]=history.getInt("noB", -1);
			pQue[1][1]=history.getInt("neB", -1);
			SendingData("B");
		}
		if(history.getInt("noC", -1)!=-1){
			pQue[2][0]=history.getInt("noC", -1);
			pQue[2][1]=history.getInt("neC", -1);
			SendingData("C");
		}
		if(history.getInt("noD", -1)!=-1){
			pQue[3][0]=history.getInt("noD", -1);
			pQue[3][1]=history.getInt("neD", -1);
			SendingData("D");
		}

		switch(NoOfG){
			case 1:	setContentView(R.layout.main_1p);
					initialise(1);
					break;
			case 2:	setContentView(R.layout.main_2p);
					initialise(2);
					break;
			case 3:	setContentView(R.layout.activity_main);
					initialise(3);
					break;
			case 4:setContentView(R.layout.main_4p);
					initialise(4);
					break;
		}

	}
	
	public void initialise(int g){
		SharedPreferences history = getSharedPreferences("NoHistory", 0);
		
		((TextView) findViewById(R.id.Gp1name)).setText(history.getString("nam1", ""));
		update(1);
		if(g>1){
			((TextView) findViewById(R.id.Gp2name)).setText(history.getString("nam2", ""));
			update(2);}
		if(g>2){
			((TextView) findViewById(R.id.Gp3name)).setText(history.getString("nam3", ""));
			update(3);}
		if(g>3){
			((TextView) findViewById(R.id.Gp4name)).setText(history.getString("nam4", ""));
			update(4);}
		/*
		Bundle ppl = this.getIntent().getExtras();
		if(g==1){
			((TextView) findViewById(R.id.Gp1name)).setText(ppl.getString("GP1"));
			update(1);
		}else if(g==2){
			((TextView) findViewById(R.id.Gp1name)).setText(ppl.getString("GP1"));
			update(1);
			
			((TextView) findViewById(R.id.Gp2name)).setText(ppl.getString("GP2"));
			update(2);
		}else if(g==3){
			((TextView) findViewById(R.id.Gp1name)).setText(ppl.getString("GP1"));
			update(1);
			
			((TextView) findViewById(R.id.Gp2name)).setText(ppl.getString("GP2"));
			update(2);
			
			((TextView) findViewById(R.id.Gp3name)).setText(ppl.getString("GP3"));
			update(3);
		}else if(g==4){
			((TextView) findViewById(R.id.Gp1name)).setText(ppl.getString("GP1"));
			update(1);
			
			((TextView) findViewById(R.id.Gp2name)).setText(ppl.getString("GP2"));
			update(2);
			
			((TextView) findViewById(R.id.Gp3name)).setText(ppl.getString("GP3"));
			update(3);
			
			((TextView) findViewById(R.id.Gp4name)).setText(ppl.getString("GP4"));
			update(4);
		}else{
			new AlertDialog.Builder(this)
			.setTitle("Warning")
			.setMessage("WTF are u doing...")
			.show();
			}*/
		
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);	
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onPause(){
	       super.onPause();

	      // We need an Editor object to make preference changes.
	      // All objects are from android.context.Context
	      SharedPreferences history = getSharedPreferences("NoHistory", 0);
	      SharedPreferences.Editor editor = history.edit();
	      editor.putInt("noA",pQue[0][0]);
	      if(NoOfG>1){editor.putInt("noB",pQue[1][0]);}
	      if(NoOfG>2){editor.putInt("noC",pQue[2][0]);}
	      if(NoOfG>3){editor.putInt("noD",pQue[3][0]);}

	      editor.putInt("neA",pQue[0][1]);
	      if(NoOfG>1){editor.putInt("neB",pQue[1][1]);}
	      if(NoOfG>2){editor.putInt("neC",pQue[2][1]);}
	      if(NoOfG>3){editor.putInt("neD",pQue[3][1]);}
	      editor.commit();
	      
	}
	/*
	//checking function that held 2 parameters
	//public int check(int queueType, int infoReturn)
	//when infoReturn == 1(now), find till que[x] is 1
	//when infoReturn == 2(new), find till que[x] is 0
	//return value:
	//		"-1" is incorrect input
	//		"-2" is empty queue
	//		"-3" is unqueued queue
	public int check(int type, int info){
		//pos = position, tar = target value (0/1)
		int pos=-1, tar =-1;
		boolean empty = true, queue = false;
		
		//set target value according to input
		if(info==1){tar=1;}
		else if(info==2){tar=0;}
		else {pos= -1;return pos;}
		type--;
		
		//check if the que is empty
		if(pQue[type][1] >= 0){empty = false;}
	
		//check if there is any queued ticket
		if(pQue[type][1] < pQue[type][0]){queue = true;}
		
		//return code if empty or queued
		if(empty) {pos=-2;return pos;}
		if(!queue){pos=-3;return pos;}
		
		//not empty and queued
		for(pos=pQue[type][info];pos<99 && que[type][pos]!=tar;pos++){}
		return pos;
	}*/
	
	public void seated(int type){
		if(pQue[type][1]>pQue[type][0] && pQue[type][1]!=-1){
			//que[type][pQue[type][0]]=2;
			pQue[type][0]++;
		}
	}
	
	public void newTic(int type){
		//if there is nthing before
		if(pQue[type][1]==-1){
			pQue[type][0]=0;
			pQue[type][1]=0;
		}
		//reach maximum in that turn
		/*if(pQue[type][1]==49){
			new AlertDialog.Builder(this)
		    .setTitle("Notice")
		    .setMessage("seated of group A")
		    .show();
			turn ++;
			for()
			
		}else{*/
		//que[type][(pQue[type][1]+1)]=1;
		pQue[type][1]++;
		}
	
	public void backOne(int type){
		if(pQue[type][1]!=-1 && pQue[type][1]>pQue[type][0]){
			//que[type][pQue[type][1]]=0;
			pQue[type][1]--;
		}
	}
	
	public void update(int g){
		int[][] value = new int[4][2];
		
		for(int i=0;i<4;i++){
			for(int x=0;x<2;x++){
				if(pQue[i][x]==-1){
					value[i][x]=0;
				}else{
					value[i][x]=pQue[i][x];
				}
			}
		}
		
		if(g==1){
			TextView noA = (TextView) findViewById(R.id.textView1);
			TextView neA = (TextView) findViewById(R.id.textView4);
			neA.setText("A"+value[0][1]);
			noA.setText("A"+value[0][0]);
		}else if(g==2){
			TextView noB = (TextView) findViewById(R.id.textView2);
			TextView neB = (TextView) findViewById(R.id.textView5);
			neB.setText("B"+value[1][1]);
			noB.setText("B"+value[1][0]);
		}else if(g==3){
			TextView noC = (TextView) findViewById(R.id.textView3);
			TextView neC = (TextView) findViewById(R.id.textView6);
			neC.setText("C"+value[2][1]);
			noC.setText("C"+value[2][0]);
		}else{
			TextView noD = (TextView) findViewById(R.id.textView7);
			TextView neD = (TextView) findViewById(R.id.textView8);
			neD.setText("D"+value[3][1]);
			noD.setText("D"+value[3][0]);
		}
	}
	
	//seated of group A
	public void cl_bA1(View cvView){
		seated(0);
		if(pQue[0][0]>0){SendingData("A");}
		update(1);
	}
	//seated of group B
	public void cl_bB1(View cvView){
		seated(1);
		if(pQue[1][0]>0){SendingData("B");}
		update(2);
	}	
	//seated of group C
	public void cl_bC1(View cvView){
		seated(2);
		if(pQue[2][0]>0){SendingData("C");}
		update(3);
	}
	//seated of group D
	public void cl_bD1(View cvView){
		seated(3);
		if(pQue[3][0]>0){SendingData("D");}
		update(4);
	}
	
	
	//ticket_print & new No. of group A
	public void cl_bA2(View cvView){
		newTic(0);
		update(1);
	}
	//ticket_print & new No. of group B
	public void cl_bB2(View cvView){
		newTic(1);
		update(2);
	}
	//ticket_print & new No. of group C
	public void cl_bC2(View cvView){
		newTic(2);
		update(3);
	}
	//ticket_print & new No. of group D
	public void cl_bD2(View cvView){
		newTic(3);
		update(4);
	}
	
	//backward of group A
	public void cl_bA3(View cvView){
		backOne(0);
		update(1);
	}
	//backward of group B
	public void cl_bB3(View cvView){
		backOne(1);
		update(2);
	}
	//backward of group C
	public void cl_bC3(View cvView){
		backOne(2);
		update(3);
	}
	//backward of group D
	public void cl_bD3(View cvView){
		backOne(3);
		update(4);
	}
	
	public void cl_logo(View cvView){
		
		SharedPreferences history = getSharedPreferences("NoHistory", 0);
	    SharedPreferences.Editor editor = history.edit();
	    editor.clear();
	    editor.commit();
		
	    for(int i=0; i<4; i++){
			pQue[i][0]=-1;
			pQue[i][1]=-1;
	    }
	    
	    update(1);
		if(NoOfG>1){update(2);}
		if(NoOfG>2){update(3);}
		if(NoOfG>3){update(4);}
		SendingData("A");
		SendingData("B");
		SendingData("C");
		SendingData("D");
	}
	
	public void SendingData(String Head){
		int value = 0;
		switch(Head){
		case "A":if(pQue[0][0]>0){value=pQue[0][0];}
				 new SendData().execute(Head+value);
				 Log.d("Send", Head+pQue[0][0]);
				 break;
		case "B":if(pQue[1][0]>0){value=pQue[1][0];}
				 new SendData().execute(Head+value);
				 Log.d("Send", Head+pQue[1][0]);
				 break;
		case "C":if(pQue[2][0]>0){value=pQue[2][0];}
		 		 new SendData().execute(Head+value);
				 Log.d("Send", Head+pQue[2][0]);
				 break;
		case "D":if(pQue[3][0]>0){value=pQue[3][0];}
		 		 new SendData().execute(Head+value);
				 Log.d("Send", Head+pQue[3][0]);
				 break;
		}
	}
	
	public class SendData extends AsyncTask<String,String,String>{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        
		@Override
		protected String doInBackground(String... params) {
			data=new HashMap<String,String>();
        	data.put("name",params[0]);
            
            Log.d("BackGround", "Finishing Setting HashMap variable- data");

            try{
                phpDataSend.postToPHP(url, data);
            }catch (Exception e){
            	e.printStackTrace();
            }
			return null;
		}
		
		@Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pDialog=new ProgressDialog(MainActivity.this);
            pDialog.setIndeterminate(false);
            pDialog.setMessage("Connecting...");
            pDialog.show();
            pDialog.cancel();
        }
	}
}
