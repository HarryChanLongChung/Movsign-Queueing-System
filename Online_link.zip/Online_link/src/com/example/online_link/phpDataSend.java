package com.example.online_link;

	import java.io.BufferedWriter;
	import java.io.IOException;
	import java.io.InputStream;
	import java.io.OutputStream;
	import java.io.OutputStreamWriter;
	import java.io.UnsupportedEncodingException;
	import java.net.HttpURLConnection;
	import java.net.MalformedURLException;
	import java.net.URL;
	import java.net.URLEncoder;
	import java.util.HashMap;
	import java.util.Map;

	import org.json.JSONObject;

	import android.util.Log;

	//this class is just for output
	public class phpDataSend {
		public phpDataSend() {}
		
	    private static HttpURLConnection urlConnection;
	    
	    public static void postToPHP(String link, HashMap<String,String> data){
	    	
			try {
				
				//initiate POST method
				URL url = new URL(link);
				urlConnection= (HttpURLConnection) url.openConnection();
		        urlConnection.setReadTimeout(10000);
		        urlConnection.setConnectTimeout(15000);
		        urlConnection.setRequestMethod("POST");
		        urlConnection.setDoOutput(true);

		        //setting output stream
	            OutputStream outStr = urlConnection.getOutputStream();
	            
	            //prepare buffered writer
	            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outStr, "UTF-8"));
	            //get data from the Hash Map thing
	            writer.write(getQuery(data));
	            
	            Log.d("Sending", "finish writing Query: "+ getQuery(data));
	            //send the writer
	            writer.flush();
	            //close the buffered writer
	            writer.close();
	            //close the output stream
	            outStr.close();

	            urlConnection.connect();
	            Log.d("Sending", "finish sending");
	            
	            InputStream inStr = urlConnection.getInputStream();

			} catch (MalformedURLException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    	
	    }
	    
	    
	    //the Jsonobject format is :
	    //{"GroupName":"A","Data":"6"}
	    //Quert format is :
	    //var_name=value
	    private static String getQuery(HashMap<String,String> data){
	        StringBuilder result = new StringBuilder();
	        boolean first = true;
	        
	        for (Map.Entry<String,String> entry: data.entrySet()){
	            if (first){first = false;}
	            else{result.append("&");}

	            try {
					result.append(URLEncoder.encode(entry.getKey(),"UTF-8"));
					result.append("=");
		            result.append(URLEncoder.encode(entry.getValue(),"UTF-8"));
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
	        }
	        Log.d("Sending", result.toString());
	        return result.toString();
	    }
	}
