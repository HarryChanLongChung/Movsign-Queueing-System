package com.example.online_link;

import android.support.v7.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class SelectionActivity extends Activity {
	
	public int sel=0;
	private ProgressDialog pDialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.selection);
		
		SharedPreferences history = getSharedPreferences("NoHistory", 0);
		if(history.getInt("NoOfPPL", -1)!=-1){
			
			pDialog=new ProgressDialog(SelectionActivity.this);
            pDialog.setIndeterminate(false);
            pDialog.setMessage("loading...");
            pDialog.show();
            
			int ppl = history.getInt("NoOfPPL", -1);
			click(ppl);
			((EditText)findViewById(R.id.editText1)).setText(history.getString("nam1", ""));
			if(ppl>1){((EditText)findViewById(R.id.editText2)).setText(history.getString("nam2", ""));}
			if(ppl>2){((EditText)findViewById(R.id.editText3)).setText(history.getString("nam3", ""));}
			if(ppl>3){((EditText)findViewById(R.id.editText4)).setText(history.getString("nam4", ""));}
			
			pDialog.cancel();
		}
		
		
	}

	
	public void click(int ppl){
		ImageView ppl1 = (ImageView) findViewById(R.id.imageView1);
		ImageView ppl2 = (ImageView) findViewById(R.id.imageView2);
		ImageView ppl3 = (ImageView) findViewById(R.id.imageView3);
		ImageView ppl4 = (ImageView) findViewById(R.id.imageView4); 
		
		ppl1.setImageResource(R.drawable.but1);
		ppl2.setImageResource(R.drawable.but2);
		ppl3.setImageResource(R.drawable.but3);
		ppl4.setImageResource(R.drawable.but4);
		
		switch(ppl){
			case 1:ppl1.setImageResource(R.drawable.but1_pre);break;
			case 2:ppl2.setImageResource(R.drawable.but2_pre);break;
			case 3:ppl3.setImageResource(R.drawable.but3_pre);break;
			case 4:ppl4.setImageResource(R.drawable.but4_pre);break;
		}
		
		sel = ppl;
	}
	
	public void cl_startCount_bt(View cvView){
		//check if the user select the no. of group
		//if yes, send all required info
		//if no , show warning
		
		 if(sel!=0){
			boolean pass= true;
			
			String nam1="", nam2="", nam3="",nam4="";
			Intent Count = new Intent(this, MainActivity.class);
			nam1 = ((EditText)findViewById(R.id.editText1)).getText().toString();
			nam2 = ((EditText)findViewById(R.id.editText2)).getText().toString();
			nam3 = ((EditText)findViewById(R.id.editText3)).getText().toString();
			nam4 = ((EditText)findViewById(R.id.editText4)).getText().toString();
			
			if(nam1.matches("")){warningNotice(1);pass=false;}
			else if(sel>1 && nam2.matches("")){warningNotice(2);pass=false;}
			else if(sel>2 && nam3.matches("")){warningNotice(3);pass=false;}
			else if(sel>3 && nam4.matches("")){warningNotice(4);pass=false;}
			
			if(pass){
				SharedPreferences history = getSharedPreferences("NoHistory", 0);
				SharedPreferences.Editor editor = history.edit();
				
				if(sel>1){editor.putString("nam2", nam2);}
				if(sel>2){editor.putString("nam3", nam3);}
				if(sel>3){editor.putString("nam4", nam4);}
				
				editor.putString("nam1", nam1);
				editor.putInt("NoOfPPL", sel);
				editor.commit();
				startActivity(Count);
			}
			
		}else{
			warningNotice(0);
		}
	}

	public void cl_1ppl(View cvView){
		click(1);
	}
	public void cl_2ppl(View cvView){
		click(2);
	}
	public void cl_3ppl(View cvView){
		click(3);
	}
	public void cl_4ppl(View cvView){
		click(4);
	}
	
	public void warningNotice(int type){
		String sign = "";
		switch(type){
			case 0:sign = "Not yet select the no. of group"; break;
			case 1:sign = "Group 1 name not yet declare"; break;
			case 2:sign = "Group 2 name not yet declare"; break;
			case 3:sign = "Group 3 name not yet declare"; break;
			case 4:sign = "Group 4 name not yet declare"; break;
		}
		new AlertDialog.Builder(this)
	    .setTitle("Notice")
	    .setMessage(sign)
	    .show();
	}
}
//Below is just for reference

/*
	use status_bt to start the page of result(Send:FromMain)
	public void cl_status_bt(View cvView){
		getGrade();
		if(grade01 != -1){
			Intent MyStatus = new Intent(this, MyStatus.class);
			MyStatus.putExtra("FromMain", grade01);
			startActivity(MyStatus);
		}else{
			showCreateDialog();
		}
	}
	
	Bundle grade02 = this.getIntent().getExtras();
	grade = grade02.getInt("FromMain");
*/
