package com.example.online_link;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class InitPage extends Activity {
	private EditText et1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_init_page);
		
		SharedPreferences history = getSharedPreferences("NoHistory", 0);
		SharedPreferences.Editor editor = history.edit();
		//if "1stTime" doesn't exist
		if((history.getInt("1stTime", -1))==-1){
			editor.putInt("1stTime", 1);
			editor.commit();
		}
		//only if it is not the first time , set stored value in edittext 
		if((history.getInt("1stTime", -1))==0){
			/*
			 * et1 = (EditText)findViewById(R.id.EditText01);
			 * et1.setText(history.getString("URL", "no stored url"));
			 */	
			Intent Select = new Intent(this, SelectionActivity.class);
			startActivity(Select);
			
		}
		
	}
	
	public void startClick(View cvView){
		et1 = (EditText)findViewById(R.id.EditText01);
		SharedPreferences history = getSharedPreferences("NoHistory", 0);
	    SharedPreferences.Editor editor = history.edit();
	    Intent Select = new Intent(this, SelectionActivity.class);
	    
	    editor.putString("URL", et1.getText().toString());
	    editor.commit();
	    
	    //firstTime storing
	    if((history.getInt("1stTime", -1))==1){
	    	//set "1st time" column to false
	    	editor.putInt("1stTime", 0);
	    	editor.commit();
	    }

	    //start activity
		startActivity(Select);
		
	}
}
